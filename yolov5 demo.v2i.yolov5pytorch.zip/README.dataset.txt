# yolov5 demo > 2025-01-05 11:39pm
https://universe.roboflow.com/sign-language-sjkru/yolov5-demo-wdmxz

Provided by a Roboflow user
License: CC BY 4.0

